 <!-- Latest compiled and minified CSS -->
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
    <script type="text/javascript">
        new WOW().init();
    </script>
    <link rel="stylesheet" href="/web/css/home.css" type="text/css" >
    <link rel="stylesheet" href="/web/css/footer.css" type="text/css">
    <link rel="stylesheet" href="/web/css/header.css" type="text/css">
    <link rel="stylesheet" href="/web/css/cart_items.css" type="text/css">
    <link rel="stylesheet" href="/web/css/account_songdev.css" type="text/css" >
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/><?php /**PATH C:\xampp\htdocs\graments\resources\views/web/layout/style.blade.php ENDPATH**/ ?>