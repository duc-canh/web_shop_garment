
<?php $__env->startSection('title'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Orders
                            <small>List</small>
                        </h1>
                        <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>

                    <?php endif; ?>
                    </div>
                    <!-- /.col-lg-12 -->
                    <table class="table table-striped table-bordered table-hover" >
                        <thead>
                            <tr align="center">
                                <th>ID</th>
                                <th>User</th>
                                <th>Product name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Price</th>
                                <th>Total count</th>
                                <th>Total money</th>
                               
                                <th>Delete</th>
                               
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="odd gradeX" align="center">
                                <td><?php echo e($order->id); ?></td>
                                <td><?php echo e($order->user->name); ?></td>
                                <td><?php echo e($order->title); ?></td>
                                <td><?php echo e($order->email); ?></td>
                                <td><?php echo e($order->phone); ?></td>
                                <td><?php echo e($order->price); ?></td>
                                <td><?php echo e($order->total_count); ?></td>
                                <td><?php echo e($order->total_money); ?></td>
                                <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a href="<?php echo e(route('admin.user.delete',$user->id )); ?>"> Delete</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\graments\resources\views/admin/order/index.blade.php ENDPATH**/ ?>