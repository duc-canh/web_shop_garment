<footer>
    <div class="container">
        <div class="left box">
            <div class="upper">
                <div class="topic">About us</div>
                <p>GRACIOUS GARMENTS sis selling various types of GARMENTS for both men and
                    women.</p>
            </div>
            <div class="footer-logo">
                <div class="topic">Download our App</div>
                <p>Download App for Android and Ios  mobile phone</p>
                <div class="app-logo">
                    <img src="../images/play-store.png">
                    <img src="../images/app-store.png">
                </div>
            </div>
        </div>
        <div class="middle box">
            <div class="topic">Our Services</div>
            <div><a href="#">Advertisement of garment products</a></div>
            <div><a href="#">Designing garment products</a></div>
            <div><a href="#">Selling and distributing products</a></div>

            <div class="lower">
                <div class="topic">Contact us</div>
                <div class="phone">
                    <a href="#"><i class="fas fa-phone-volume"></i>+84 4953 0134</a>
                </div>
                <div class="email">
                    <a href="#"><i class="fas fa-envelope"></i>Graciousgarments@gmail.com</a>
                </div>
            </div>
        </div>
        <div class="right box">
            <div class="topic">Subscribe us</div>
            <form action="#">
                <label>
                    <input type="text" placeholder="Enter email address">
                </label>
                <input type="submit" name="" value="Send">
                <div class="media-icons">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-youtube"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </form>
        </div>
    </div>
    <div class="bottom">
        <p>Copyright © 2020 <a href="https://garments-shop.herokuapp.com/">GRACIOUS GARMENTS</a> All rights reserved</p>
    </div>
</footer>