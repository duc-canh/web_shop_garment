
<script src="/web/js/header-rs.js"></script>
<script src="/web/js/header-scorll.js"></script>
<script src="/web/js/click-buy.js"></script>
<script src="/web/js/main-fn.js"></script>
<!-- <script src="https://unpkg.com/sweetalert/dist/<script src="/web./js/jquery-3.6.0.min.js"></script>sweetalert.min.js"></script> -->
<script type="text/javascript " src="/web//js/account_SongDev.js"></script>